# metodos_optimizacion/multivariada/__init__.py
from .directos import *
from .gradiente import *

__all__ = ['directos', 'gradiente']
