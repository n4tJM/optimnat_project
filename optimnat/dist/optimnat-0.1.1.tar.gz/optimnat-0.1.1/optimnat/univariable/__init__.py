# metodos_optimizacion/una_variable/__init__.py
from .eliminacion_regiones import *
from .derivada import *

__all__ = ['eliminacion_regiones', 'derivada']
