from .univariable import *
from .multivariable import *
from .funciones import *

__all__ = ['univariable', 'multivariable', 'funciones']